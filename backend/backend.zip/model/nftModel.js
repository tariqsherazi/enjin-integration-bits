const { NftModal } = require("../schema/nftSchema");
//save methods

const createNFt = async (obj) => {
  try {
    const name = obj.name;
    const artist_name1 = obj.artist_name1;
    const video = obj.video;
    const description = obj.description;
    const token_id = obj.token_id;
    const supply = obj.supply;
    const wallet_address = obj.wallet_address;
    const status = obj.status;
    const royalty = obj.royalty;
    const user_id = obj.user_id;

    const createNftDataIntoDb = await NftModal.create({
      name,
      artist_name1,
      video,
      description,
      token_id,
      supply,
      wallet_address,
      royalty,
      user_id,
    });

    if (!createNftDataIntoDb) throw "error";
    return createNftDataIntoDb;
  } catch (error) {
    console.log(error);
    throw new Error(error);
  }
};

//get methods
const getNFtsModal = async (args) => {
  try {
    const wallet_address = args.walletAddress;
    console.log("wallet_address", wallet_address);
    const getALlNfts = await NftModal.find({
      wallet_address: wallet_address,
    }).populate("user_id");

    if (!getALlNfts) throw "error";
    return getALlNfts;
  } catch (error) {
    console.log(error);
    throw new Error(error);
  }
};

//get All Nfts methods
const getAllNftsModal = async (args) => {
  try {
    const getALlNfts = await NftModal.find({}).populate("user_id");

    if (!getALlNfts) throw "error";
    return getALlNfts;
  } catch (error) {
    console.log(error);
    throw new Error(error);
  }
};

// mint Nft
const mintNft = async (args) => {
  try {
    const wallet_address = args.walletAddress;
    const updateNft = await NftModal.updateOne(
      { wallet_address: wallet_address },
      {
        $set: {
          status: true,
        },
      }
    );

    if (updateNft) {
      return {
        status: true,
      };
    }
  } catch (error) {
    throw new Error(error);
  }
};

const updateNftStatus = async (args) => {
  try {
    const nft = await NftModal.findOne({ _id: args?.id });

    if (nft) {
      nft.is_blocked = !nft.is_blocked;
      await nft.save();
      console.log("NFT status updated successfully!");
    } else {
      console.log("NFT not found.");
    }
    return nft;
  } catch (error) {
    throw new Error(error);
  }
};

const getAllNftsForAdmin = async (args) => {
  try {
    const res = await NftModal.find();

    if (!res) throw "error";
    return res;
  } catch (error) {
    console.log(error);
    throw new Error(error);
  }
};

module.exports = {
  createNFt,
  getNFtsModal,
  mintNft,
  getAllNftsModal,
  getAllNftsForAdmin,
  updateNftStatus,
};
